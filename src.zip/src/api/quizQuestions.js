
var quizQuestions = [
  {
      question: "India is a developing country ? ",
      answers: [
          {
              type: 1,
              content: "yes"
              
          },
          {
              type: 0,
              content: "no"
          }
      ]
  },
  {
      question: "delhi is the capital of india ? ",
      answers: [
          {
              type: 1,
              content: "yes"
          },
         
          {
              type: 0,
              content: "no"
          }
      ]
  },
  {
      question: "lion is a national animal ?",
      answers: [
          {
              type: 1,
              content: "yes"
          },
          
          {
              type: 0,
              content: "no"
          }
      ]
  },
  {
      question: "peacock is a national bird ?",
      answers: [
          {
              type: 1,
              content: "yes"
          },
          
          {
              type: 0,
              content: "no"
          }
      ]
  },
  {
      question: " lotus is a national flower ? ",
      answers: [
          {
              type: 1,
              content: "yes"
          },
          
          {
              type: 0,
              content: "no"
          }
      ]
  }
];
 
export default quizQuestions;